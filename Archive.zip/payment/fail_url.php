<h1 style='text-align:center;'>Payment was failed.</h1>
<a href='/'>Home Page</a>