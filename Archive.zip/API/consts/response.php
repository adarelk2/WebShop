<?php
///ENUM OF STATUS/////
define("STATUS_SUCCESS",200);
define("STATUS_CREATED",201);
define("STATUS_DELETED",204);
define("STATUS_BAD_REQUEST",500);

define("RESPONSE_SUCCESS","!הצלחנו");
define("RESPONSE_ERROR","הפעולה נכשלה, יש לנסות שוב");
define("CUSTOMER_HAS_NO_LOANER","ללקוח זה אין מכשיר חלופי");
define("EMAIL_NOT_SENT","לא הצלחנו לשלוח מייל ללקוח");
define("NO_PERMISSIONS","אין לך הרשאות עבור פעולה זאת");
?>