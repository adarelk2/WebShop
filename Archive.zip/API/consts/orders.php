<?php
define('LAST_HOUR', '1');

?>