<?php
$line = [];
$line[0] = "About Our Shop";
$line[1] = "Flipper Zero is a portable multi-tool for pentesters and geeks in a toy-like body. It loves hacking digital stuff, such as radio protocols, access control systems, hardware and more. It's fully open-source and customizable, so you can extend it in whatever way you like.";
$line[2] = "Our favorite products";
$line[3] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labor e et dolore magna aliqua. Ut enim ad minim veniam, qui";
?>