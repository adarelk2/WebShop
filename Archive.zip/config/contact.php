<?php
$Email = "test@gmail.com";
$PhoneNumber = "+01 1234567890";
$Location = "Location";
?>