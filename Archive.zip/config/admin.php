<?php
define('ADMIN_USERNAME', '12341234');
define('ADMIN_PASSWORD', '12341234');
?>