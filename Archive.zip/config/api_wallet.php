<?php
define('API_BTC_KEY', '$2y$10$wU5.dtUGf8j2A2kiZHewj.8JFpHhhbO7Fv9sVEwNa7Zsivxqmjb76');
define('API_BTC_PASSWORD', '681998Ae');
define('notify_url', 'http://flipperzeroisrael.com/payment/notify_url.php');
define('suceess_url', 'http://flipperzeroisrael.com/payment/suceess_url.php');
define('fail_url', 'http://flipperzeroisrael.com/payment/fail_url.php');

?>