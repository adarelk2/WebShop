<?php
define('USER_NORMAL', '1');
define('USER_MANAGER', '2');
?>